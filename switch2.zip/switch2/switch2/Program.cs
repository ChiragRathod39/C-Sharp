﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace switch2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("set console color black=1");
            Console.WriteLine("set console color blue=2");
            Console.WriteLine("set console color yellow=3");

            int n = Convert.ToInt32(Console.ReadLine());
            switch (n)
            {
                case 1: Console.BackgroundColor = ConsoleColor.Black;
                    Console.Clear();
                    break;

                case 2: Console.BackgroundColor = ConsoleColor.Blue;
                    Console.Clear();
                    break;

                case 3: Console.BackgroundColor = ConsoleColor.Yellow;
                    Console.Clear();
                    break;

                 default:Console.Write("select 1 2 3");
                     break; 
            }
            Console.Read();
        }
    }
}

           
        
    

