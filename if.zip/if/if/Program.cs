﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace @if
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter your age:");
            int a = Convert.ToInt32(Console.ReadLine());
            if (a <= 0)
            {
                Console.WriteLine("not available");
            }
            else
            {
                if (a < 18)
                {
                    Console.WriteLine("teenage");
                }
                else if (a > 18 && a < 60)
                {
                    Console.WriteLine("young age");
                }
                else if (a > 60 && a < 100)
                {
                    Console.WriteLine("senior citizen");
                }
                else
                {
                    Console.WriteLine("enter proper number of age");
                }
                Console.Read();
            }
        }
    }
}
