﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace forpyramid
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter any number:");
            int n = Convert.ToInt32(Console.ReadLine());
            int i, o = 2, w = 3, x = 1;
            for (i = 1; i <= n; i++)
            {
                int j;
                for (j = 1; j <= i; j++)
                {
                    if (x <= 3)
                    {
                        Console.Write(x + " ");
                    }
                    else
                    {
                        x = o * w;
                        if (x > n)
                        {
                            break;
                        }
                        Console.Write(x + " ");
                        o = w;
                        w = x;
                    }
                    x++;

                }

                if (x > n)
                {
                    break;
                }
                Console.WriteLine();
            }
            Console.Read();

        }
    }
}


    