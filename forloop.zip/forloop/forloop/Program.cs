﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace forloop
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter any number:");
            int n = Convert.ToInt32(Console.ReadLine());
            int i, j = 2, k = 3;
            for (i = 1; i <= n; i++)
            {
                if (i <= 3)
                {
                    Console.Write(i + " ");

                }
                else
                {
                    i = j * k;
                    if (i >= n)
                    {
                        break;
                    }
                    Console.Write(i + " ");
                    j = k;
                    k = i;
                }


            }
            Console.Read();
        }
    }

}