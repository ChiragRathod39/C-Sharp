﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace boxing
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 20;
            object obj = i;
            Console.WriteLine(obj);
            int j = (int)obj;
            Console.Write(j);
            Console.Read();

        }
    }
}
