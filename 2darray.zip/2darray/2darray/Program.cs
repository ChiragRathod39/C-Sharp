﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2darray
{
    class Program
    {
        static void Main(string[] args)
        {
            //2d array
            int[,] a = new int[2, 2];
            a[0, 0] = 1;
            a[0, 1] = 2;
            a[1, 0] = 3;
            a[1, 1] = 4;
            foreach (int i in a)
            {
                Console.Write(" " + i);




            }
            Console.Read();
        }
    }
}