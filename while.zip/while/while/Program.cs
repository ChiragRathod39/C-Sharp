﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace @while
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter any number:");
            int n = Convert.ToInt32(Console.ReadLine());
            int i = 1, j = 2, k = 3;
            while (i <= n)
            {
                if (i <= 3)
                {
                    Console.Write(i + " ");
                    i++;
                }
                else
                {
                    i = j * k;
                    if (i >= n)
                    {
                        break;
                    }
                    Console.Write(i + " ");
                    j = k;
                    k = i;
                }


            }
            Console.Read();
        }
    }
}
